# Akoya Miner 2.0.0

Standalone pool miner for Pearl.

Required:

    AKOYA_POOL_WALLET=PRL1... ./akoya-miner mine-blocks

Optional:

    AKOYA_POOL_HOST=pool-v2.akoyapool.com
    AKOYA_POOL_PORT=443
    AKOYA_POOL_USE_TLS=1
    AKOYA_POOL_WORKER=my-rig
    AKOYA_GPU_INDICES=all
